#include <Windows.h>
#include <Psapi.h>
#include <fstream>
#include <string>
#include <thread>
#include <filesystem>

typedef struct lua_State lua_State;
typedef int  (*luaL_loadstring_t)(lua_State*, const char*);
typedef int  (*lua_pcall_t)      (lua_State*, int, int, int);
typedef const char* (*lua_tolstring_t)(lua_State*, int, size_t*);
typedef void (*lua_settop_t)     (lua_State*, int);

// ── Оффсеты — найди актуальные через PatternScan ниже ──
namespace Offsets {
    uintptr_t luaL_loadstring = 0x0;
    uintptr_t lua_pcall       = 0x0;
    uintptr_t lua_tolstring   = 0x0;
    uintptr_t lua_settop      = 0x0;
    uintptr_t rL              = 0x0;
}

uintptr_t GetBase() { return (uintptr_t)GetModuleHandleA("RobloxPlayerBeta.exe"); }

// ── Поиск паттерна — запускай один раз для получения оффсетов ──
uintptr_t PatternScan(const char* pattern, const char* mask) {
    uintptr_t base = GetBase();
    MODULEINFO mi{}; GetModuleInformation(GetCurrentProcess(), (HMODULE)base, &mi, sizeof(mi));
    size_t mlen = strlen(mask);
    for (uintptr_t i = base; i < base + mi.SizeOfImage - mlen; i++) {
        bool found = true;
        for (size_t j = 0; j < mlen; j++) {
            if (mask[j] == 'x' && *(BYTE*)(i+j) != (BYTE)pattern[j]) { found = false; break; }
        }
        if (found) return i;
    }
    return 0;
}

// ── Автопоиск оффсетов (Lua 5.1 паттерны) ──
void FindOffsets() {
    // luaL_loadstring: 55 8B EC 8B 55 08 8B 45 0C
    Offsets::luaL_loadstring = PatternScan(
        "\x55\x8B\xEC\x8B\x55\x08\x8B\x45\x0C",
        "xxxxxxxxx") - GetBase();

    // lua_pcall: 55 8B EC 83 EC 10 53 56 57 8B 7D 08
    Offsets::lua_pcall = PatternScan(
        "\x55\x8B\xEC\x83\xEC\x10\x53\x56\x57\x8B\x7D\x08",
        "xxxxxxxxxxxx") - GetBase();

    // Пишем найденные оффсеты в лог для следующего раза
    char tmp[MAX_PATH]; GetTempPathA(MAX_PATH, tmp);
    std::ofstream log(std::string(tmp) + "rbx_offsets.txt");
    log << "luaL_loadstring: 0x" << std::hex << Offsets::luaL_loadstring << "\n";
    log << "lua_pcall:       0x" << std::hex << Offsets::lua_pcall       << "\n";
    log.close();
}

bool ExecuteScript(const std::string& script) {
    if (!Offsets::rL || !Offsets::luaL_loadstring || !Offsets::lua_pcall) return false;

    uintptr_t base = GetBase();
    auto _loadstring = (luaL_loadstring_t)(base + Offsets::luaL_loadstring);
    auto _pcall      = (lua_pcall_t)      (base + Offsets::lua_pcall);
    auto _tolstring  = (lua_tolstring_t)  (base + Offsets::lua_tolstring);
    auto _settop     = (lua_settop_t)     (base + Offsets::lua_settop);

    lua_State* L = *(lua_State**)(base + Offsets::rL);
    if (!L) return false;

    if (_loadstring(L, script.c_str()) != 0) {
        const char* err = _tolstring(L, -1, nullptr);
        OutputDebugStringA(err ? err : "load error");
        _settop(L, -2); return false;
    }
    if (_pcall(L, 0, -1, 0) != 0) {
        const char* err = _tolstring(L, -1, nullptr);
        OutputDebugStringA(err ? err : "call error");
        _settop(L, -2); return false;
    }
    return true;
}

// ── Pipe сервер — читает скрипты от UI ──
void PipeServer() {
    const wchar_t* name = L"\\\\.\\pipe\\RbxExec";
    while (true) {
        HANDLE h = CreateNamedPipeW(name,
            PIPE_ACCESS_INBOUND,
            PIPE_TYPE_BYTE|PIPE_READMODE_BYTE|PIPE_WAIT,
            1, 0, 65536, 0, nullptr);
        if (h == INVALID_HANDLE_VALUE) { Sleep(500); continue; }

        if (ConnectNamedPipe(h, nullptr) || GetLastError() == ERROR_PIPE_CONNECTED) {
            std::string script;
            char buf[4096]; DWORD read = 0;
            while (ReadFile(h, buf, sizeof(buf)-1, &read, nullptr) && read > 0) {
                buf[read] = '\0'; script += buf;
            }
            if (!script.empty()) ExecuteScript(script);
        }
        CloseHandle(h);
    }
}

// ── Bridge файл watcher — читает %TEMP%\rbx_bridge.lua ──
void BridgeWatcher() {
    char tmp[MAX_PATH]; GetTempPathA(MAX_PATH, tmp);
    std::string path = std::string(tmp) + "rbx_bridge.lua";
    std::filesystem::file_time_type last{};
    while (true) {
        Sleep(100);
        if (!std::filesystem::exists(path)) continue;
        auto t = std::filesystem::last_write_time(path);
        if (t == last) continue;
        last = t;
        std::ifstream f(path);
        if (!f.is_open()) continue;
        std::string s((std::istreambuf_iterator<char>(f)), {});
        f.close();
        if (!s.empty() && s.find("bridge ready") == std::string::npos)
            ExecuteScript(s);
    }
}

BOOL APIENTRY DllMain(HMODULE hMod, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hMod);
        std::thread(FindOffsets).detach();
        std::thread(PipeServer).detach();
        std::thread(BridgeWatcher).detach();
    }
    return TRUE;
}
