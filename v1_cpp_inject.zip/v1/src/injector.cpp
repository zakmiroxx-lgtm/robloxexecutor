#include <Windows.h>
#include <TlHelp32.h>
#include <Psapi.h>
#include <iostream>
#include <string>

DWORD GetPID(const wchar_t* procName) {
    DWORD pid = 0;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe{}; pe.dwSize = sizeof(pe);
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, procName) == 0) { pid = pe.th32ProcessID; break; }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

bool InjectDLL(DWORD pid, const char* dllPath) {
    HANDLE hProc = OpenProcess(
        PROCESS_CREATE_THREAD|PROCESS_VM_OPERATION|
        PROCESS_VM_WRITE|PROCESS_VM_READ|PROCESS_QUERY_INFORMATION,
        FALSE, pid);
    if (!hProc) { std::cerr << "[-] OpenProcess failed: " << GetLastError() << "\n"; return false; }

    size_t pathLen = strlen(dllPath) + 1;
    LPVOID remoteAddr = VirtualAllocEx(hProc, nullptr, pathLen, MEM_COMMIT|MEM_RESERVE, PAGE_READWRITE);
    if (!remoteAddr) { std::cerr << "[-] VirtualAllocEx failed: " << GetLastError() << "\n"; CloseHandle(hProc); return false; }

    if (!WriteProcessMemory(hProc, remoteAddr, dllPath, pathLen, nullptr)) {
        std::cerr << "[-] WriteProcessMemory failed: " << GetLastError() << "\n";
        VirtualFreeEx(hProc, remoteAddr, 0, MEM_RELEASE); CloseHandle(hProc); return false;
    }

    LPVOID loadLib = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");
    HANDLE hThread = CreateRemoteThread(hProc, nullptr, 0, (LPTHREAD_START_ROUTINE)loadLib, remoteAddr, 0, nullptr);
    if (!hThread) {
        std::cerr << "[-] CreateRemoteThread failed: " << GetLastError() << "\n";
        VirtualFreeEx(hProc, remoteAddr, 0, MEM_RELEASE); CloseHandle(hProc); return false;
    }

    WaitForSingleObject(hThread, 5000);
    DWORD exitCode = 0; GetExitCodeThread(hThread, &exitCode);
    std::cout << "[+] Thread exit code: 0x" << std::hex << exitCode << "\n";
    CloseHandle(hThread); VirtualFreeEx(hProc, remoteAddr, 0, MEM_RELEASE); CloseHandle(hProc);
    return exitCode != 0;
}

bool InjectDLL_Syscall(DWORD pid, const char* dllPath) {
    HANDLE hNtdll = CreateFileA("C:\\Windows\\System32\\ntdll.dll",
        GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (hNtdll == INVALID_HANDLE_VALUE) return false;

    HANDLE hMap = CreateFileMappingA(hNtdll, nullptr, PAGE_READONLY|SEC_IMAGE, 0, 0, nullptr);
    CloseHandle(hNtdll);
    if (!hMap) return false;

    LPVOID cleanNtdll = MapViewOfFile(hMap, FILE_MAP_READ, 0, 0, 0);
    CloseHandle(hMap);
    if (!cleanNtdll) return false;

    HMODULE hLiveNtdll = GetModuleHandleA("ntdll.dll");
    FARPROC procAddr = GetProcAddress(hLiveNtdll, "NtCreateThreadEx");
    if (procAddr) {
        DWORD oldProt;
        VirtualProtect(procAddr, 8, PAGE_EXECUTE_READWRITE, &oldProt);
        DWORD_PTR offset = (DWORD_PTR)procAddr - (DWORD_PTR)hLiveNtdll;
        memcpy(procAddr, (LPVOID)((DWORD_PTR)cleanNtdll + offset), 8);
        VirtualProtect(procAddr, 8, oldProt, &oldProt);
    }
    UnmapViewOfFile(cleanNtdll);
    return InjectDLL(pid, dllPath);
}

int main() {
    std::cout << "XcX Injector v67\n";
    std::cout << "[*] Looking for RobloxPlayerBeta.exe...\n";

    DWORD pid = GetPID(L"RobloxPlayerBeta.exe");
    if (!pid) { std::cerr << "[-] Roblox not found.\n"; system("pause"); return 1; }
    std::cout << "[+] PID: " << pid << "\n";

    char dllPath[MAX_PATH];
    GetFullPathNameA("executor.dll", MAX_PATH, dllPath, nullptr);
    std::cout << "[*] DLL: " << dllPath << "\n";

    if (GetFileAttributesA(dllPath) == INVALID_FILE_ATTRIBUTES) {
        std::cerr << "[-] executor.dll not found.\n"; system("pause"); return 1;
    }

    if (InjectDLL_Syscall(pid, dllPath))
        std::cout << "[+] Injected (syscall bypass).\n";
    else if (InjectDLL(pid, dllPath))
        std::cout << "[+] Injected (standard).\n";
    else
        std::cerr << "[-] Injection failed.\n";

    system("pause");
    return 0;
}
