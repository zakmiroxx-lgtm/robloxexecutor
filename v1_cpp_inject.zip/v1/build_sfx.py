import os, sys, struct, zipfile, subprocess, io

SRC_EXE  = os.path.join("dist", "RbxExecutor.exe")
STUB_SRC = os.path.join("stub", "sfx_stub.py")
STUB_EXE = os.path.join("dist", "sfx_stub.exe")
OUT_DIR  = "output"
OUT_SFX  = os.path.join(OUT_DIR, "RbxExecutor_Setup.exe")
MARKER   = b"__PAYLOAD_START__"

def build_stub():
    print("[*] Building sfx_stub...")
    ret = subprocess.call([sys.executable,"-m","PyInstaller","--onefile","--noconsole","--name","sfx_stub",STUB_SRC])
    if ret != 0: print("[!] sfx_stub failed"); sys.exit(1)
    print("[+] sfx_stub.exe done.")

def pack():
    if not os.path.exists(SRC_EXE): print("[!] Missing: "+SRC_EXE); sys.exit(1)
    os.makedirs(OUT_DIR, exist_ok=True)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        zf.write(SRC_EXE, arcname="RbxExecutor.exe")
    zip_data = buf.getvalue()
    with open(STUB_EXE,"rb") as f: stub = f.read()
    with open(OUT_SFX,"wb") as f:
        f.write(stub); f.write(MARKER)
        f.write(struct.pack("<I",len(zip_data))); f.write(zip_data)
    print("[+] SFX ready: "+OUT_SFX+" ("+str(os.path.getsize(OUT_SFX)//1024)+" KB)")

if __name__ == "__main__":
    if not os.path.exists(STUB_EXE): build_stub()
    pack()
