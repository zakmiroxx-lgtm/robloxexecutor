import tkinter as tk
from tkinter import scrolledtext, ttk
import threading
import subprocess
import os
import sys
import ctypes
import ctypes.wintypes
import struct
import time

INJECT_STATUS = {"connected": False, "pid": None}

# ──────────────────────────────────────────────
# Win32 API
# ──────────────────────────────────────────────
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

PROCESS_ALL_ACCESS     = 0x1F0FFF
MEM_COMMIT             = 0x1000
MEM_RESERVE            = 0x2000
MEM_RELEASE            = 0x8000
PAGE_EXECUTE_READWRITE = 0x40
PIPE_ACCESS_DUPLEX     = 0x00000003
PIPE_TYPE_BYTE         = 0x00000000
PIPE_WAIT              = 0x00000000
INVALID_HANDLE_VALUE   = ctypes.wintypes.HANDLE(-1).value

# ──────────────────────────────────────────────
# Найти Roblox PID
# ──────────────────────────────────────────────
def find_roblox_pid():
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq RobloxPlayerBeta.exe", "/FO", "CSV", "/NH"],
            stderr=subprocess.DEVNULL, text=True
        )
        for line in out.strip().splitlines():
            parts = line.strip('"').split('","')
            if len(parts) >= 2:
                try:
                    return int(parts[1])
                except ValueError:
                    continue
    except Exception:
        pass
    return None

# ──────────────────────────────────────────────
# Named Pipe инжект
# Roblox executor bridge через \\.\pipe\RbxExec
# ──────────────────────────────────────────────
PIPE_NAME = r"\\.\pipe\RbxExec"
_pipe_server_running = False
_pipe_handle = None

def start_pipe_server(log_fn):
    global _pipe_server_running, _pipe_handle
    _pipe_server_running = True

    def _server():
        global _pipe_handle
        while _pipe_server_running:
            try:
                _pipe_handle = kernel32.CreateNamedPipeW(
                    PIPE_NAME,
                    PIPE_ACCESS_DUPLEX,
                    PIPE_TYPE_BYTE | PIPE_WAIT,
                    1, 65536, 65536,
                    0, None
                )
                if _pipe_handle == INVALID_HANDLE_VALUE:
                    log_fn("[!] Pipe create failed: " + str(ctypes.get_last_error()))
                    time.sleep(1)
                    continue

                log_fn("[+] Pipe server listening: " + PIPE_NAME)
                connected = kernel32.ConnectNamedPipe(_pipe_handle, None)
                if connected or ctypes.get_last_error() == 535:  # ERROR_PIPE_CONNECTED
                    log_fn("[✓] Client connected to pipe.")
                kernel32.CloseHandle(_pipe_handle)
            except Exception as e:
                log_fn("[!] Pipe error: " + str(e))
            time.sleep(0.5)

    threading.Thread(target=_server, daemon=True).start()

def send_via_pipe(script: str, log_fn):
    """Пишем скрипт в pipe — Roblox читает с другой стороны."""
    try:
        handle = kernel32.CreateFileW(
            PIPE_NAME,
            0x40000000,   # GENERIC_WRITE
            0, None,
            3,            # OPEN_EXISTING
            0, None
        )
        if handle == INVALID_HANDLE_VALUE:
            raise OSError("Cannot open pipe: " + str(ctypes.get_last_error()))

        data = script.encode("utf-8")
        written = ctypes.wintypes.DWORD(0)
        ok = kernel32.WriteFile(handle, data, len(data), ctypes.byref(written), None)
        kernel32.CloseHandle(handle)

        if ok:
            log_fn(f"[+] Pipe: sent {written.value} bytes.")
        else:
            log_fn("[!] Pipe write failed: " + str(ctypes.get_last_error()))
    except Exception as e:
        log_fn("[!] Pipe send error: " + str(e))

# ──────────────────────────────────────────────
# WriteProcessMemory инжект (fallback)
# Записываем Lua скрипт в память процесса
# ──────────────────────────────────────────────
def inject_via_wpm(pid: int, script: str, log_fn):
    try:
        h_proc = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)
        if not h_proc:
            log_fn("[!] OpenProcess failed: " + str(ctypes.get_last_error()))
            return False

        payload = script.encode("utf-8") + b"\x00"
        size    = len(payload)

        addr = kernel32.VirtualAllocEx(
            h_proc, None, size,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_EXECUTE_READWRITE
        )
        if not addr:
            log_fn("[!] VirtualAllocEx failed: " + str(ctypes.get_last_error()))
            kernel32.CloseHandle(h_proc)
            return False

        written = ctypes.c_size_t(0)
        ok = kernel32.WriteProcessMemory(
            h_proc, addr,
            ctypes.c_char_p(payload), size,
            ctypes.byref(written)
        )
        if not ok:
            log_fn("[!] WriteProcessMemory failed: " + str(ctypes.get_last_error()))
            kernel32.VirtualFreeEx(h_proc, addr, 0, MEM_RELEASE)
            kernel32.CloseHandle(h_proc)
            return False

        log_fn(f"[+] WPM: {written.value} bytes written @ 0x{addr:X}")

        # Пишем адрес в temp файл — executor stub в Roblox читает его
        ptr_path = os.path.join(os.getenv("TEMP", "C:\\Temp"), "rbx_ptr.bin")
        with open(ptr_path, "wb") as f:
            f.write(struct.pack("<Q", addr))
        log_fn("[+] Ptr saved: " + ptr_path)

        kernel32.CloseHandle(h_proc)
        return True

    except Exception as e:
        log_fn("[!] WPM error: " + str(e))
        return False

# ──────────────────────────────────────────────
# Bridge файл (универсальный fallback)
# ──────────────────────────────────────────────
def write_bridge(script: str, log_fn):
    path = os.path.join(os.getenv("TEMP", "C:\\Temp"), "rbx_bridge.lua")
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(script)
        log_fn("[+] Bridge written: " + path)
    except Exception as e:
        log_fn("[!] Bridge error: " + str(e))

# ──────────────────────────────────────────────
# Connect
# ──────────────────────────────────────────────
def connect(log_fn):
    pid = find_roblox_pid()
    if not pid:
        log_fn("[!] Roblox not found. Launch the game first.")
        return False

    log_fn(f"[+] Roblox found — PID {pid}")
    INJECT_STATUS["pid"] = pid
    INJECT_STATUS["connected"] = True

    start_pipe_server(log_fn)
    log_fn("[✓] Connected. Ready to inject.")
    return True

# ──────────────────────────────────────────────
# Execute — пробуем все методы по порядку
# ──────────────────────────────────────────────
def execute(script: str, log_fn):
    if not INJECT_STATUS["connected"]:
        log_fn("[!] Not connected. Hit Connect first.")
        return

    pid = INJECT_STATUS["pid"]
    log_fn("[*] Injecting...")

    # 1) Named Pipe
    send_via_pipe(script, log_fn)

    # 2) WriteProcessMemory
    inject_via_wpm(pid, script, log_fn)

    # 3) Bridge file (для кастомных executor stub'ов)
    write_bridge(script, log_fn)

    log_fn("[✓] Script dispatched via all channels.")

# ──────────────────────────────────────────────
# GUI
# ──────────────────────────────────────────────
QUICK_SCRIPTS = {
    "Infinite Yield":   'loadstring(game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"))()',
    "Dex Explorer":     'loadstring(game:HttpGet("https://raw.githubusercontent.com/infyiff/backup/main/dex.lua"))()',
    "ESP (simple)":     '''
for _, v in ipairs(workspace:GetDescendants()) do
    if v:IsA("Model") and v:FindFirstChildOfClass("Humanoid") then
        local bb = Instance.new("BillboardGui", v.PrimaryPart or v:FindFirstChild("HumanoidRootPart"))
        bb.AlwaysOnTop = true; bb.Size = UDim2.new(0,60,0,20)
        local lbl = Instance.new("TextLabel", bb)
        lbl.Size = UDim2.new(1,0,1,0); lbl.Text = v.Name
        lbl.BackgroundTransparency = 1; lbl.TextColor3 = Color3.new(1,0,0)
    end
end''',
    "Custom URL":       'loadstring(game:HttpGet("PASTE_URL_HERE"))()',
}

class ExecutorApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("XcX Executor v67")
        self.root.geometry("760x580")
        self.root.configure(bg="#0d0d0d")
        self.root.resizable(False, False)
        self._build_ui()

    def _build_ui(self):
        # Header
        top = tk.Frame(self.root, bg="#0d0d0d")
        top.pack(fill="x", padx=16, pady=(14, 0))

        tk.Label(top, text="XcX EXECUTOR",
                 bg="#0d0d0d", fg="#c0392b",
                 font=("Consolas", 20, "bold")).pack(side="left")

        self.status_lbl = tk.Label(top, text="● DISCONNECTED",
                                    bg="#0d0d0d", fg="#3d3d3d",
                                    font=("Consolas", 9))
        self.status_lbl.pack(side="right", pady=6)

        tk.Label(self.root, text="v67  ·  6767",
                 bg="#0d0d0d", fg="#2a2a2a",
                 font=("Consolas", 8)).pack(anchor="w", padx=16)

        tk.Frame(self.root, bg="#1a1a1a", height=1).pack(fill="x", padx=16, pady=(6, 8))

        # Quick scripts bar
        qs_frame = tk.Frame(self.root, bg="#0d0d0d")
        qs_frame.pack(fill="x", padx=16, pady=(0, 6))

        tk.Label(qs_frame, text="Quick:",
                 bg="#0d0d0d", fg="#444",
                 font=("Consolas", 8)).pack(side="left", padx=(0, 6))

        for name, code in QUICK_SCRIPTS.items():
            tk.Button(
                qs_frame, text=name,
                bg="#141414", fg="#666",
                activebackground="#1e1e1e", activeforeground="#aaa",
                font=("Consolas", 8), relief="flat",
                padx=8, pady=3, cursor="hand2", bd=0,
                command=lambda c=code: self._load_quick(c)
            ).pack(side="left", padx=2)

        # Editor
        tk.Label(self.root, text="Script Editor",
                 bg="#0d0d0d", fg="#444",
                 font=("Consolas", 8)).pack(anchor="w", padx=16)

        self.editor = scrolledtext.ScrolledText(
            self.root,
            bg="#111111", fg="#e0e0e0",
            insertbackground="#c0392b",
            selectbackground="#c0392b",
            selectforeground="#fff",
            font=("Consolas", 11),
            relief="flat", height=12,
            wrap="none", padx=8, pady=8
        )
        self.editor.pack(fill="x", padx=16, pady=(2, 8))
        self.editor.insert("end",
            'loadstring(game:HttpGet("https://gist.githubusercontent.com/'
            'OfficialCynatica/636bed3e9ba0088733feb986768f8015/raw"))()\n'
        )

        # Buttons
        btn = tk.Frame(self.root, bg="#0d0d0d")
        btn.pack(fill="x", padx=16, pady=(0, 8))

        self.connect_btn = tk.Button(
            btn, text="⚡  CONNECT",
            bg="#c0392b", fg="white",
            activebackground="#e74c3c", activeforeground="white",
            font=("Consolas", 11, "bold"),
            relief="flat", padx=20, pady=7,
            cursor="hand2", bd=0,
            command=self._on_connect
        )
        self.connect_btn.pack(side="left", padx=(0, 8))

        self.exec_btn = tk.Button(
            btn, text="▶  EXECUTE",
            bg="#1c1c1c", fg="#555",
            activebackground="#222", activeforeground="#aaa",
            font=("Consolas", 11),
            relief="flat", padx=20, pady=7,
            cursor="hand2", bd=0, state="disabled",
            command=self._on_execute
        )
        self.exec_btn.pack(side="left", padx=(0, 8))

        tk.Button(
            btn, text="✕  CLEAR",
            bg="#0d0d0d", fg="#333",
            activebackground="#111",
            font=("Consolas", 10),
            relief="flat", padx=12, pady=7,
            cursor="hand2", bd=0,
            command=lambda: self.editor.delete("1.0", "end")
        ).pack(side="left")

        # Inject method indicator
        self.method_lbl = tk.Label(
            btn, text="pipe  ·  wpm  ·  bridge",
            bg="#0d0d0d", fg="#252525",
            font=("Consolas", 8)
        )
        self.method_lbl.pack(side="right")

        # Log
        tk.Label(self.root, text="Log",
                 bg="#0d0d0d", fg="#333",
                 font=("Consolas", 8)).pack(anchor="w", padx=16)

        self.log = scrolledtext.ScrolledText(
            self.root,
            bg="#080808", fg="#444",
            font=("Consolas", 9),
            relief="flat", height=6,
            state="disabled", padx=6, pady=6
        )
        self.log.pack(fill="x", padx=16, pady=(2, 14))

    def _load_quick(self, code: str):
        self.editor.delete("1.0", "end")
        self.editor.insert("end", code.strip() + "\n")

    def _log(self, msg: str):
        def _w():
            self.log.configure(state="normal")
            self.log.insert("end", msg + "\n")
            self.log.see("end")
            self.log.configure(state="disabled")
        self.root.after(0, _w)

    def _on_connect(self):
        self.connect_btn.configure(state="disabled", text="  Connecting...")
        def _run():
            ok = connect(self._log)
            if ok:
                self.root.after(0, lambda: [
                    self.connect_btn.configure(bg="#27ae60", text="✓  CONNECTED", state="normal"),
                    self.exec_btn.configure(bg="#1c1c1c", fg="#e0e0e0", state="normal"),
                    self.status_lbl.configure(text="● CONNECTED", fg="#27ae60"),
                    self.method_lbl.configure(fg="#333")
                ])
            else:
                self.root.after(0, lambda: self.connect_btn.configure(
                    bg="#c0392b", text="⚡  CONNECT", state="normal"
                ))
        threading.Thread(target=_run, daemon=True).start()

    def _on_execute(self):
        script = self.editor.get("1.0", "end").strip()
        if not script:
            self._log("[!] Script is empty.")
            return
        threading.Thread(target=execute, args=(script, self._log), daemon=True).start()


def main():
    root = tk.Tk()
    ExecutorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
