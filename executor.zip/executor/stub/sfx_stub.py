"""
sfx_stub.py — компилируется в sfx_stub.exe через PyInstaller.
При запуске: читает себя, находит payload после маркера,
распаковывает в %TEMP%\\RbxExecutor\\ и запускает RbxExecutor.exe.
"""
import sys
import os
import struct
import zipfile
import tempfile
import subprocess
import io

MARKER = b"__PAYLOAD_START__"


def extract_and_run():
    exe_path = sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__)

    with open(exe_path, "rb") as f:
        data = f.read()

    idx = data.find(MARKER)
    if idx == -1:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, "Payload not found in SFX.", "XcX Executor", 0x10)
        sys.exit(1)

    offset = idx + len(MARKER)
    zip_size = struct.unpack_from("<I", data, offset)[0]
    zip_data = data[offset + 4: offset + 4 + zip_size]

    out_dir = os.path.join(tempfile.gettempdir(), "RbxExecutor")
    os.makedirs(out_dir, exist_ok=True)

    with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
        zf.extractall(out_dir)

    target = os.path.join(out_dir, "RbxExecutor.exe")
    if not os.path.exists(target):
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, f"RbxExecutor.exe not found in {out_dir}", "XcX Executor", 0x10)
        sys.exit(1)

    subprocess.Popen([target], cwd=out_dir, close_fds=True)


if __name__ == "__main__":
    extract_and_run()
