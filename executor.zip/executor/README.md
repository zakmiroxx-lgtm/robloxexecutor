# XcX Executor v67

Roblox executor. Открываешь программу — сам решаешь когда жать Connect.

## Как использовать

1. Открой Roblox (игра должна быть уже запущена)
2. Запусти `RbxExecutor_Setup.exe` — он сам распакуется и стартует
3. Нажми **CONNECT** — программа найдёт Roblox
4. Вставь Lua скрипт в редактор
5. **EXECUTE**

## Build через GitHub Actions

Пушишь в `main` → Actions сам билдит → скачиваешь `RbxExecutor_Setup.exe` из Artifacts.

## Локальный билд

```bat
pip install -r requirements.txt
pyinstaller --onefile --noconsole --name RbxExecutor src/main.py
python build_sfx.py
```

Итог в `output/RbxExecutor_Setup.exe`

---
6767
