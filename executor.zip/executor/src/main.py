import tkinter as tk
from tkinter import scrolledtext
import threading
import subprocess
import os
import sys
import time

INJECT_STATUS = {"connected": False, "pid": None}

# ──────────────────────────────────────────────
# Найти Roblox PID
# ──────────────────────────────────────────────
def find_roblox_pid():
    try:
        result = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq RobloxPlayerBeta.exe", "/FO", "CSV", "/NH"],
            stderr=subprocess.DEVNULL,
            text=True
        )
        for line in result.strip().splitlines():
            parts = line.strip('"').split('","')
            if len(parts) >= 2:
                try:
                    return int(parts[1])
                except ValueError:
                    continue
    except Exception:
        pass
    return None

# ──────────────────────────────────────────────
# Коннект (только когда игрок нажал)
# ──────────────────────────────────────────────
def inject_and_connect(log_fn):
    pid = find_roblox_pid()
    if not pid:
        log_fn("[!] Roblox не найден. Открой игру и попробуй снова.")
        return False

    log_fn(f"[+] Roblox найден — PID {pid}")
    INJECT_STATUS["pid"] = pid

    bridge_path = os.path.join(os.getenv("TEMP", "C:\\Temp"), "rbx_bridge.lua")
    try:
        with open(bridge_path, "w", encoding="utf-8") as f:
            f.write("-- XcX Executor bridge ready\nprint('[XcX] Connected')\n")
        log_fn(f"[+] Bridge: {bridge_path}")
    except Exception as e:
        log_fn(f"[!] Bridge error: {e}")
        return False

    INJECT_STATUS["connected"] = True
    log_fn("[✓] Подключено. Пиши скрипт и жми Execute.")
    return True

# ──────────────────────────────────────────────
# Запустить скрипт
# ──────────────────────────────────────────────
def execute_script(script, log_fn):
    if not INJECT_STATUS["connected"]:
        log_fn("[!] Сначала нажми Connect.")
        return
    bridge_path = os.path.join(os.getenv("TEMP", "C:\\Temp"), "rbx_bridge.lua")
    try:
        with open(bridge_path, "w", encoding="utf-8") as f:
            f.write(script)
        log_fn("[+] Скрипт отправлен.")
    except Exception as e:
        log_fn(f"[!] Ошибка: {e}")

# ──────────────────────────────────────────────
# GUI
# ──────────────────────────────────────────────
class ExecutorApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("XcX Executor v67")
        self.root.geometry("720x520")
        self.root.configure(bg="#0d0d0d")
        self.root.resizable(False, False)
        self._build_ui()

    def _build_ui(self):
        # ── Title bar area
        top = tk.Frame(self.root, bg="#0d0d0d")
        top.pack(fill="x", padx=16, pady=(14, 0))

        tk.Label(
            top, text="XcX EXECUTOR",
            bg="#0d0d0d", fg="#c0392b",
            font=("Consolas", 20, "bold")
        ).pack(side="left")

        self.status_label = tk.Label(
            top, text="● DISCONNECTED",
            bg="#0d0d0d", fg="#3d3d3d",
            font=("Consolas", 9)
        )
        self.status_label.pack(side="right", pady=6)

        tk.Label(
            self.root, text="v67  ·  6767",
            bg="#0d0d0d", fg="#2a2a2a",
            font=("Consolas", 8)
        ).pack(anchor="w", padx=16)

        tk.Frame(self.root, bg="#1a1a1a", height=1).pack(fill="x", padx=16, pady=(6, 10))

        # ── Script editor
        tk.Label(
            self.root, text="Script Editor",
            bg="#0d0d0d", fg="#555",
            font=("Consolas", 8)
        ).pack(anchor="w", padx=16)

        self.editor = scrolledtext.ScrolledText(
            self.root,
            bg="#111111", fg="#e0e0e0",
            insertbackground="#c0392b",
            selectbackground="#c0392b",
            selectforeground="#fff",
            font=("Consolas", 11),
            relief="flat",
            height=13,
            wrap="none",
            padx=8, pady=8
        )
        self.editor.pack(fill="x", padx=16, pady=(2, 10))
        self.editor.insert("end", "-- Roblox открыт? Жми Connect, потом пиши сюда скрипт.\n")

        # ── Buttons
        btn_frame = tk.Frame(self.root, bg="#0d0d0d")
        btn_frame.pack(fill="x", padx=16, pady=(0, 8))

        self.connect_btn = tk.Button(
            btn_frame,
            text="⚡  CONNECT",
            bg="#c0392b", fg="white",
            activebackground="#e74c3c",
            activeforeground="white",
            font=("Consolas", 11, "bold"),
            relief="flat",
            padx=20, pady=7,
            cursor="hand2",
            bd=0,
            command=self._on_connect
        )
        self.connect_btn.pack(side="left", padx=(0, 8))

        self.exec_btn = tk.Button(
            btn_frame,
            text="▶  EXECUTE",
            bg="#1c1c1c", fg="#888",
            activebackground="#222",
            activeforeground="#aaa",
            font=("Consolas", 11),
            relief="flat",
            padx=20, pady=7,
            cursor="hand2",
            bd=0,
            state="disabled",
            command=self._on_execute
        )
        self.exec_btn.pack(side="left", padx=(0, 8))

        tk.Button(
            btn_frame,
            text="✕  CLEAR",
            bg="#0d0d0d", fg="#333",
            activebackground="#111",
            font=("Consolas", 10),
            relief="flat",
            padx=12, pady=7,
            cursor="hand2",
            bd=0,
            command=self._clear
        ).pack(side="left")

        # ── Log
        tk.Label(
            self.root, text="Log",
            bg="#0d0d0d", fg="#333",
            font=("Consolas", 8)
        ).pack(anchor="w", padx=16)

        self.log_box = scrolledtext.ScrolledText(
            self.root,
            bg="#080808", fg="#444",
            font=("Consolas", 9),
            relief="flat",
            height=5,
            state="disabled",
            padx=6, pady=6
        )
        self.log_box.pack(fill="x", padx=16, pady=(2, 14))

    def _log(self, msg: str):
        def _write():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", msg + "\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        self.root.after(0, _write)

    def _clear(self):
        self.editor.delete("1.0", "end")

    def _on_connect(self):
        self.connect_btn.configure(state="disabled", text="  Connecting...")

        def run():
            ok = inject_and_connect(self._log)
            if ok:
                self.root.after(0, lambda: [
                    self.connect_btn.configure(
                        bg="#27ae60", text="✓  CONNECTED", state="normal"
                    ),
                    self.exec_btn.configure(
                        bg="#1c1c1c", fg="#e0e0e0",
                        activeforeground="white",
                        state="normal"
                    ),
                    self.status_label.configure(
                        text="● CONNECTED", fg="#27ae60"
                    )
                ])
            else:
                self.root.after(0, lambda: self.connect_btn.configure(
                    bg="#c0392b", text="⚡  CONNECT", state="normal"
                ))

        threading.Thread(target=run, daemon=True).start()

    def _on_execute(self):
        script = self.editor.get("1.0", "end").strip()
        if not script:
            self._log("[!] Скрипт пустой.")
            return
        threading.Thread(
            target=execute_script,
            args=(script, self._log),
            daemon=True
        ).start()


def main():
    root = tk.Tk()
    app = ExecutorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
