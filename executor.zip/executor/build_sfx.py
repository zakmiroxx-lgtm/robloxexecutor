"""
build_sfx.py
Запускается после того как PyInstaller собрал оба EXE.
Упаковывает RbxExecutor.exe в SFX архив.

Итог: output/RbxExecutor_Setup.exe
"""
import os
import sys
import struct
import zipfile
import shutil
import subprocess

SRC_EXE  = os.path.join("dist", "RbxExecutor.exe")
STUB_SRC = os.path.join("stub", "sfx_stub.py")
STUB_EXE = os.path.join("dist", "sfx_stub.exe")
OUT_DIR  = "output"
OUT_SFX  = os.path.join(OUT_DIR, "RbxExecutor_Setup.exe")
MARKER   = b"__PAYLOAD_START__"


def build_stub():
    print("[*] Компилируем sfx_stub...")
    ret = subprocess.call([
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole",
        "--name", "sfx_stub",
        STUB_SRC
    ])
    if ret != 0:
        print("[!] sfx_stub билд упал.")
        sys.exit(1)
    print("[+] sfx_stub.exe готов.")


def pack():
    os.makedirs(OUT_DIR, exist_ok=True)

    # Zip основной exe
    zip_buf = __import__("io").BytesIO()
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        zf.write(SRC_EXE, arcname="RbxExecutor.exe")
    zip_data = zip_buf.getvalue()

    # Читаем stub
    with open(STUB_EXE, "rb") as f:
        stub_data = f.read()

    # Пишем SFX: stub_bytes | MARKER | zip_size_LE_4bytes | zip_bytes
    with open(OUT_SFX, "wb") as f:
        f.write(stub_data)
        f.write(MARKER)
        f.write(struct.pack("<I", len(zip_data)))
        f.write(zip_data)

    size_kb = os.path.getsize(OUT_SFX) // 1024
    print(f"[+] SFX готов: {OUT_SFX}  ({size_kb} KB)")


if __name__ == "__main__":
    if not os.path.exists(STUB_EXE):
        build_stub()
    pack()
